import moment from 'moment';

export const getCurrentYear = () => moment().format('YYYY');
